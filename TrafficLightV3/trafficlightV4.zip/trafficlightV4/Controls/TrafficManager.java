package trafficlightV4.Controls;

public class TrafficManager {

	public TrafficManager() {
		TrafficLightViewManager.getInstance();
	}

	public static void main(String[] args) {
		new TrafficManager();
	}

}
