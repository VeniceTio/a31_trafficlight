package trafficlightV4.Model;

public interface City {
    public void changeColor(TrafficLight trafficLight);
    public String getType();
}
