package trafficlightV4.Model;

public enum LightColor {
	GREEN,
	RED,
	ORANGE
};

